"""
An example in rst
=================
"""

import numpy as np

##############################################################################
# This is a title
# ---------------
# Let's do ..

x=np.zeros(2)
print(x)